#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "HashTableAPI.h"
#include "ReadData.h"

void addWord(HTable *ht);
void removeWord(HTable* ht);
void spellCheck(HTable *ht);
void printDictionary(HTable *ht);
