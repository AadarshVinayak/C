#include <stdio.h>
#include <stdlib.h>

void deleteInt(void *toBeDeleted);
int compareInt(const void *first, const void *second);
void printInt(void* toBePrinted);
